<?php
/**
 * Version: 0.1.2 (2025-05-31)
 * File Description: 商品推薦ロジックの雛形クラス。Geminiレスポンスの保存機能と会話履歴対応を追加。
 */

namespace MobesAi\Core\AiCore;
use MobesAi\Core\AiCore\AiLogger;
use MobesAi\Core\AiCore\GeminiClient;

class RecommendationService
{
    public function getRecommendations(string $mode, int $orderSessionId = null, string $lineUserId = null): array
    {
        $logger = new AiLogger();
        $logger->info('RecommendationService getRecommendations start', ['mode' => $mode, 'session' => $orderSessionId]);
        // 商品プール取得
        require_once __DIR__ . '/../../../../api/lib/Database.php';
        $db = \Database::getInstance();

        try {
            $products = $db->select("SELECT p.id, p.name, p.description, p.price, p.category, p.category_name, p.image_url, l1.label_name AS label1, l2.label_name AS label2 FROM products p LEFT JOIN item_label l1 ON l1.id = p.item_label1 LEFT JOIN item_label l2 ON l2.id = p.item_label2 WHERE p.is_active=1 AND p.presence=1 LIMIT 400");
        } catch (\Throwable $e) {
            // テーブル or カラム不足の場合は簡易クエリへフォールバック
            $products = $db->select("SELECT id, name, description, price, category, category_name, image_url FROM products WHERE is_active=1 AND presence=1 LIMIT 400");
            foreach($products as &$row){$row['label1']=null;$row['label2']=null;}
        }

        // "recommend" は旧名称; 内部的には suggest と同一扱い
        if ($mode === 'recommend') {
            $mode = 'suggest';
        }

        // ソムリエモードの場合、酒関連商品のみ抽出
        if ($mode === 'sommelier') {
            // カテゴリ名に酒類キーワードを含む商品のみ抽出
            $keywords = ['wine', 'ワイン', 'シャンパン', 'champagne', 'カクテル', 'cocktail', 'アルコール'];
            $products = array_values(array_filter($products, function ($p) use ($keywords) {
                $hay = mb_strtolower(($p['category'] ?? '') . ' ' . ($p['category_name'] ?? ''));
                foreach ($keywords as $kw) {
                    if (strpos($hay, mb_strtolower($kw)) !== false) {
                        return true;
                    }
                }
                return false;
            }));

            // 中価格帯（25〜75パーセンタイル）に絞り込む
            if (count($products) >= 8) { // 十分なデータがある場合のみ実施
                $prices = array_column($products, 'price');
                sort($prices, SORT_NUMERIC);
                $n = count($prices);
                $lowerIdx = (int)floor($n * 0.25);
                $upperIdx = (int)ceil($n * 0.75) - 1;
                $lower = $prices[$lowerIdx];
                $upper = $prices[$upperIdx];

                $midProducts = array_values(array_filter($products, function ($p) use ($lower, $upper) {
                    return $p['price'] >= $lower && $p['price'] <= $upper;
                }));

                if (count($midProducts) >= 3) { // 極端に減る場合はフォールバックしない
                    $products = $midProducts;
                }
            }
        }

        $logger->info('Products fetched', ['count' => count($products)]);

        if (!$products) {
            return [
                'items' => [],
                'reply' => '現在おすすめできる商品がありません。'
            ];
        }

        // 注文履歴（任意）
        $historyStats = [];
        try {
            if ($orderSessionId) {
                $historyStats = $db->select("SELECT od.product_id, SUM(od.qty) AS cnt FROM orders o JOIN order_details od ON od.order_id=o.id WHERE o.order_session_id=:sid AND o.status='COMPLETED' GROUP BY od.product_id", [':sid' => $orderSessionId]);
            } elseif ($lineUserId) {
                $historyStats = $db->select("SELECT od.product_id, SUM(od.qty) AS cnt FROM orders o JOIN order_details od ON od.order_id=o.id WHERE o.line_user_id=:luid AND o.status='COMPLETED' GROUP BY od.product_id", [':luid' => $lineUserId]);
            }
        } catch (\Throwable $e) {
            $logger->warning('history query failed', ['exception'=>$e]);
            $historyStats = [];
        }

        // 会話履歴取得
        $chatHistory = [];
        try {
            if ($orderSessionId || $lineUserId) {
                $params = [];
                $whereClause = '';
                if ($orderSessionId) {
                    $whereClause = 'order_session_id = :sid';
                    $params[':sid'] = $orderSessionId;
                } else {
                    $whereClause = 'line_user_id = :luid';
                    $params[':luid'] = $lineUserId;
                }
                
                $messages = $db->select(
                    "SELECT role, message FROM mobes_ai_messages 
                     WHERE {$whereClause} 
                     ORDER BY created_at DESC 
                     LIMIT 10",
                    $params
                );
                
                // 新しい順なので逆順にする
                $chatHistory = array_reverse($messages);
                $logger->info('Chat history loaded', ['count' => count($chatHistory)]);
            }
        } catch (\Throwable $e) {
            $logger->warning('chat history query failed', ['exception' => $e]);
            $chatHistory = [];
        }

        // Prompt 準備
        $pr = new \MobesAi\Core\PromptRegistrer\PromptRegistrer();
        $systemPromptBase = $pr->getSystemPrompt($mode);
        $style = $pr->getBasicStyle();
        $prohibitions = $pr->getProhibitions();
        $chatRule = $pr->getChatRule();
        // mode による追加説明
        $modeAddon = '';
        if ($mode === 'sommelier') {
            $modeAddon = "\nあなたは熟練のソムリエです。ワインやシャンパンを中心に、中価格帯の商品から提案してください。".
                "\n【重要】出力は必ず1行目にJSON配列(product_id, qty)のみを角括弧で記述し、改行して2行目以降に日本語説明を書くこと。";
        } elseif ($mode === 'suggest') {
            $modeAddon = "\nユーザーの希望を2往復以内で聞き出し、最後に3商品を提案してください。";
        } elseif ($mode === 'omakase') {
            $modeAddon = "\nあなたはモーブスのAIコンシェルジュです。以下の条件で10品程度のフルコーディネートを作成してください。".
                "\n【必須ルール】".
                "\n1. フード系カテゴリー('フード','セルフメイドメニュー','バーガー','ピザ')から合計3品以上選ぶ。".
                "\n2. お酒カテゴリー('ビール物販','コーディアルカクテル','アルコール','赤ワイン','白ワイン','ホットアルコール','ロゼワイン','シャンパン')からは人数分。".
                "\n3. ノンアルコールドリンクカテゴリー('クラフトドリンク','ソフトドリンク')からは飲酒しない人数分を目安に選択。全員飲酒の場合は省略可。".
                "\n4. 食後のデザートとして 'スイーツ' または 'セルフメイドメニュー' から1品以上。".
                "\n5. 合計でおおむね10品前後になるよう調整し、足りない場合はバランス良く追加。".
                "\n6. 出力は1行目にJSON配列(product_id, qty)のみ、2行目に100〜200字の日本語解説とする。";
        }

        $systemPrompt = $systemPromptBase . $modeAddon . "\n文体:" . $style . "\n禁止:" . $prohibitions . "\nルール:" . $chatRule;
        $logger->info('Prompt assembled', ['system_prompt' => $systemPrompt]);
        $apiKey = $pr->getApiKey();
        $modelId = $pr->getModelId();

        $gemini = new GeminiClient($apiKey, $modelId);

        // build product array with labels
        $productJsonArray = array_map(function($row){
            $labels = array_filter([$row['label1'] ?? null, $row['label2'] ?? null]);
            return [
                'id' => (int)$row['id'],
                'name' => $row['name'],
                'description' => $row['description'] ?? '',
                'price' => (float)$row['price'],
                'category' => $row['category'],
                'category_name' => $row['category_name'] ?? null,
                'labels' => $labels,
                'image_url' => $row['image_url'] ?? null
            ];
        }, $products);

        $messages = [
            $systemPrompt,
            '以下は JSON 形式の商品一覧です。推奨商品と数量を3件返してください。',
            json_encode($productJsonArray, JSON_UNESCAPED_UNICODE),
            'ユーザ購買履歴:' . json_encode($historyStats, JSON_UNESCAPED_UNICODE)
        ];

        // 会話履歴をプロンプトに追加
        if (!empty($chatHistory)) {
            $messages[] = "\n過去の会話履歴:";
            foreach ($chatHistory as $msg) {
                $role = $msg['role'] === 'user' ? 'ユーザー' : 'アシスタント';
                $messages[] = "{$role}: {$msg['message']}";
            }
        }

        $messages[] = '【出力フォーマット厳守】1行目にJSON配列のみを出力し改行。2行目に100〜200字以内の日本語解説を出力。JSONキーは product_id, qty';

        $raw = $gemini->sendPrompt($messages);
        $logger->info('Received raw response', ['raw' => $raw]);
        if (!$raw) {
            return [
                'items' => [],
                'reply' => 'AI 推薦に失敗しました。時間を置いて再度お試しください。'
            ];
        }

        // JSON 抽出
        $items = [];
        if (preg_match('/\[(.*?)\]/s', $raw, $m)) {
            $jsonPart = '[' . $m[1] . ']';
            $decoded = json_decode($jsonPart, true);
            if (is_array($decoded)) {
                $items = array_filter($decoded, function ($row) {
                    return isset($row['product_id']) && isset($row['qty']) && $row['qty'] >= 1;
                });
            }
        }
        // 返信文 = raw から JSON 部分除外
        $replyText = trim(str_replace($jsonPart ?? '', '', $raw));

        // --- コードフェンス除去 ---
        if (!empty($replyText)) {
            // ```json や ``` を削除
            $replyText = preg_replace('/```(?:json)?\s*/i', '', $replyText);
            $replyText = str_replace('```', '', $replyText);
            $replyText = trim($replyText);
        }

        // フォールバック: items が空で raw の1行目が JSON らしければ採用
        if (empty($items)) {
            $firstLine = strtok($raw, "\n");
            $maybe = json_decode(trim($firstLine), true);
            if (is_array($maybe)) {
                $items = $maybe;
                $replyText = trim(substr($raw, strlen($firstLine)));
                // 再度コードフェンス除去
                $replyText = preg_replace('/```(?:json)?\s*/i', '', $replyText);
                $replyText = str_replace('```', '', $replyText);
                $replyText = trim($replyText);
            }
        }

        // 推薦アイテムに商品詳細を付加
        $productMap = [];
        foreach($products as $prow){
            $productMap[$prow['id']] = $prow;
        }
        foreach($items as &$it){
            $pid = $it['product_id'] ?? null;
            if($pid && isset($productMap[$pid])){
                $row = $productMap[$pid];
                $it['name'] = $row['name'];
                $it['price'] = (float)$row['price'];
                $it['image_url'] = $row['image_url'] ?? null;
            }
        }

        // Geminiからのレスポンスをデータベースに保存
        try {
            if ($orderSessionId || $lineUserId) {
                $db->insert('mobes_ai_messages', [
                    'order_session_id' => $orderSessionId ?? 0,
                    'line_user_id' => $lineUserId,
                    'role' => 'assistant',
                    'message' => $replyText
                ]);
                $logger->info('Saved assistant message to database');
            }
        } catch (\Throwable $e) {
            $logger->warning('Failed to save assistant message', ['exception' => $e]);
        }

        // Determine chat phase for omakase/suggest
        $userMsgs = array_filter($chatHistory, fn($m)=>$m['role']==='user');
        $askPhase = false;
        if(in_array($mode,['omakase','suggest'])){
            if(count($userMsgs)===0){
                $askPhase = true;
            }
        }

        // askPhase handling
        if($askPhase){
            $question = ($mode==='omakase')?
                'お酒を飲まれるか（あり／なし／一部）、ご希望の方向性（辛め・軽めなど）、そして何名様分かを教えてください。':
                'どんな味がお好みですか？例えば辛いものが好き、軽めが良い、など簡単に教えてください。';
            return ['items'=>[], 'reply'=>$question];
        }

        return [
            'items' => $items,
            'reply' => $replyText
        ];
    }
} 