<?php
/**
 * Version: 0.1.0 (2025-05-31)
 * File Description: adminsetting.json から mobes_ai prompt 設定を読み取るラッパ雛形。
 */

namespace MobesAi\Core\PromptRegistrer;
use MobesAi\Core\AiCore\AiLogger;

class PromptRegistrer
{
    private const ADMIN_REGISTRER = __DIR__ . '/../../../../admin/adminsetting_registrer.php';
    private static array $cache = [];
    /** @var string|null */
    private static ?string $settingsPath = null;

    public function __construct()
    {
        if (!defined('ADMIN_SETTING_INTERNAL_CALL')) {
            define('ADMIN_SETTING_INTERNAL_CALL', true);
        }
        if (!function_exists('loadSettings')) {
            // settingsFilePath の事前注入（bootstrap などから）
            if (self::$settingsPath) {
                $GLOBALS['settingsFilePath'] = self::$settingsPath;
            }
            require_once self::ADMIN_REGISTRER;
        }
        /**
         * Lolipop 環境では realpath() が false を返すケースがあり、
         * adminsetting_registrer.php 内の $logFile が空文字になる。
         * そのまま file_put_contents('', ...) が呼ばれると致命的エラーとなるため、
         * ここで安全なデフォルトパスを注入する。
         */
        if (empty($GLOBALS['logFile'] ?? '')) {
            $GLOBALS['logFile'] = __DIR__ . '/../../../../logs/adminsetting_registrer.log';
            $logDir = dirname($GLOBALS['logFile']);
            if (!is_dir($logDir)) {
                mkdir($logDir, 0775, true);
            }
        }
    }

    private function loadConfig(): array
    {
        $logger = new AiLogger();
        $logger->info('PromptRegistrer loadConfig start');
        if (!empty(self::$cache)) {
            $logger->info('PromptRegistrer loadConfig cache hit', ['keys' => array_keys(self::$cache)]);
            return self::$cache;
        }
        if (function_exists('loadSettings')) {
            $settings = loadSettings();
            if (is_array($settings)) {
                self::$cache = $settings;
            } else {
                // 読み込み失敗時は空配列で初期化
                $logger->warning('PromptRegistrer: settings load returned non-array', ['type' => gettype($settings)]);
                self::$cache = [];
            }
        }
        if (empty(self::$cache)) {
            $logger->warning('PromptRegistrer: settings could not be loaded');
        }
        $logger->info('PromptRegistrer loadConfig end', ['config_keys' => array_keys(self::$cache)]);
        return self::$cache;
    }

    public function getSystemPrompt(string $mode): string
    {
        $logger = new AiLogger();
        $logger->info('PromptRegistrer getSystemPrompt', ['mode' => $mode]);
        $cfg = $this->loadConfig();
        return $cfg['mobes_ai']['prompt'] ?? '';
    }

    public function getApiKey(): string
    {
        $logger = new AiLogger();
        $logger->info('PromptRegistrer getApiKey');
        $cfg = $this->loadConfig();
        return $cfg['mobes_ai']['gemini_api_key'] ?? '';
    }

    public function isStockLockEnabled(): bool
    {
        $logger = new AiLogger();
        $cfg = $this->loadConfig();
        $enabled = isset($cfg['mobes_ai']['stock lock']) && $cfg['mobes_ai']['stock lock'] === true;
        $logger->info('PromptRegistrer isStockLockEnabled', ['enabled' => $enabled]);
        return $enabled;
    }

    public function getBasicStyle(): string
    {
        $logger = new AiLogger();
        $cfg = $this->loadConfig();
        $style = $cfg['mobes_ai']['basicstyle'] ?? '';
        $logger->info('PromptRegistrer getBasicStyle', ['basicstyle' => $style]);
        return $style;
    }

    public function getProhibitions(): string
    {
        $logger = new AiLogger();
        $cfg = $this->loadConfig();
        if (isset($cfg['mobes_ai']['prohibitions']['words'])) {
            $words = implode('、', $cfg['mobes_ai']['prohibitions']['words']);
            $logger->info('PromptRegistrer getProhibitions', ['prohibitions' => $words]);
            return $words;
        }
        $logger->info('PromptRegistrer getProhibitions', ['prohibitions' => '']);
        return '';
    }

    public function getChatRule(): string
    {
        $logger = new AiLogger();
        $cfg = $this->loadConfig();
        if (isset($cfg['mobes_ai']['chatrule']['rules'])) {
            $rules = implode('、', $cfg['mobes_ai']['chatrule']['rules']);
            $logger->info('PromptRegistrer getChatRule', ['chatrule' => $rules]);
            return $rules;
        }
        $logger->info('PromptRegistrer getChatRule', ['chatrule' => '']);
        return '';
    }

    public function getRateLimitPm(): int
    {
        $logger = new AiLogger();
        $cfg = $this->loadConfig();
        $limit = isset($cfg['mobes_ai']['rate_limit_pm']) ? (int)$cfg['mobes_ai']['rate_limit_pm'] : 120;
        $logger->info('PromptRegistrer getRateLimitPm', ['rate_limit_pm' => $limit]);
        return $limit;
    }

    public function getModelId(): string
    {
        $logger = new AiLogger();
        $cfg = $this->loadConfig();
        $id = $cfg['mobes_ai']['gemini_model_id'] ?? 'chat-bison-001';
        $logger->info('PromptRegistrer getModelId', ['model_id' => $id]);
        return $id;
    }

    /** 外部から adminsetting.json の絶対パスを設定 */
    public static function setSettingsPath(string $path): void
    {
        self::$settingsPath = $path;
    }
} 