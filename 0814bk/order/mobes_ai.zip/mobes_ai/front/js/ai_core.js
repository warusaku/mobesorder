/*
 Version: 0.1.0 (2025-05-31)
 File Description: AI 会話状態管理・レスポンス描画ロジック雛形。
*/

class MobesAiCore {
  constructor() {
    console.info('[mobes_ai] ai_core.js initialized (stub)');
    // TODO: conversation state, message rendering
  }
}

// Export to global for quick testing
window.MobesAiCore = MobesAiCore; 